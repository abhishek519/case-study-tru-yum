show databases;
create database truyum;
use truyum;
create table menu (
item_id int auto_increment primary key,
item_name varchar(50),
price decimal(6,2),
active enum('Yes','No'),
date_of_launch date,
category varchar(50),
free_delivery enum('Yes','No'),
check(category in ('Starter','Main Course','Desserts','Drinks'))
);

create table user (
user_id int auto_increment primary key,
user_name varchar(100)
);

create table cart (
cart_id int auto_increment primary key,
item_id int,
user_id int,
foreign key (item_id) references menu(item_id),
foreign key (user_id) references user(user_id)
);